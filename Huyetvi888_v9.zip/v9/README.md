# ☯ Huyệt Vị 888 — Hướng Dẫn Sử Dụng

Trang tra cứu huyệt vị Đông Y — 433 huyệt vị với hình ảnh, vị trí, tác dụng và video.

---

## 1. Cách mở và chạy trang web

Giải nén file ZIP, sau đó mở file `index.html` bằng trình duyệt Chrome hoặc Edge.

```
Giải nén → Mở index.html → Xong!
```

> Không cần cài đặt gì thêm. Trang hoạt động hoàn toàn offline (ngoại trừ video YouTube và hình ảnh từ web).

**Deploy GitHub Pages:**
1. Tạo repo GitHub mới, push toàn bộ folder lên nhánh `main`
2. Settings → Pages → Deploy from branch `main` → `/root`
3. Sau vài phút truy cập tại `https://tên-của-bạn.github.io/tên-repo/`

---

## 2. Cách dùng trang Admin (admin.html) để chỉnh sửa data.js

M�� `admin.html` bằng **Chrome hoặc Edge** (bắt buộc — Firefox chưa hỗ trợ File System API).

### Bước 1 — Tải dữ liệu
- Bấm **"📂 Chọn file data.js"** → Dẫn đến `assets/js/data.js` trong thư mục dự án
- Hoặc bấm **"📋 Dán dữ liệu JSON"** → Copy nội dung file `data.js` và dán vào

### Bước 2 — Chỉnh sửa
- Danh sách huyệt hiện ở cột trái, tìm kiếm bằng ô search
- Bấm tên huyệt hoặc ✏️ để mở form chỉnh sửa
- Bấm ➕ để thêm huyệt mới
- Bấm 🗑️ để xóa huyệt

### Bước 3 — Lưu
- Bấm **"💾 Lưu"** (Ctrl+S) → Ghi trực tiếp vào file `data.js` trên máy tính
- Bấm **"📥 Tải về"** → Tải về file `data.js` mới (dùng khi Firefox hoặc quyền bị từ chối)
- Upload file `data.js` lên hosting/GitHub sau khi hoàn chỉnh

> **Lưu ý:** Sau khi lưu vào file trên máy, hãy đẩy lại lên hosting (GitHub Pages/Netlify) để cập nhật.

---

## 3. Cách thay đổi số huyệt nổi bật

M�� file `index.html`, tìm dòng:

```javascript
const FEATURED_COUNT = 8; // ← Thay đổi số này để điều chỉnh số huyệt nổi bật
```

Thay `8` bằng số bạn muốn (ví dụ: 6, 9, 12...) rồi lưu file.

---

## 4. Cách đổi theme giao diện

- Bấm nút **🎨** ở góc phải thanh điều hướng
- Chọn 1 trong 4 theme:
  - 🟢 **Ngọc Bích** — Xanh ngọc truyền thống (mặc định)
  - 🟤 **Nâu Trầm** — Nâu đất, ấm áp phong cách Á Đông
  - 🔴 **Đỏ Son** — Đỏ son phong thủy Trung Hoa
  - ⬛ **Mực Tàu** — Đen mực Tàu, huyền bí

Theme được lưu tự động vào `localStorage` — giữ nguyên khi tải lại trang hoặc đóng/mở trình duyệt.

---

## Cấu trúc thư mục

```
huyetvị888/
├── index.html          Trang chủ
├── search.html         Trang tìm kiếm
├── filter.html         Trang lọc chứng bệnh
├── detail.html         Trang chi tiết huyệt vị
├── about.html          Giới thiệu
├── admin.html          Trang quản trị nội dung
├── README.md           File này
├── assets/
│   ├── css/style.css   Toàn bộ styling
│   └── js/
│       ├── data.js     Dữ liệu 433 huyệt vị (chỉnh sửa qua Admin)
│       ├── main.js     Utilities chung + theme system
│       ├── search.js   Logic tìm kiếm
│       ├── filter.js   Logic lọc chứng bệnh
│       └── detail.js   Logic trang chi tiết
├── images/             Hình ảnh cách xác định thốn
└── danh_y/             Ảnh danh y cho slider
```

---

*© 2025 Huyệt Vị 888 — Thông tin mang tính tham khảo, không thay thế chẩn đoán y khoa.*
