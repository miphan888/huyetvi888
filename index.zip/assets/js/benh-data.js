const BENH_DATA = [
  {
    "ten": "Đau Lưng (Thắt Lưng)",
    "slug": "dau-lung-that-lung",
    "trieuChung": "Đau âm ỉ hoặc dữ dội vùng thắt lưng, có thể lan xuống mông và chân.\nNguyên nhân thường gặp:\n• Thận hư (khí huyết không nuôi dưỡng đủ kinh cân)\n• Phong hàn thấp xâm nhập kinh lạc\n• Chấn thương cơ học, sai tư thế\n• Ứ trệ khí huyết do lao động nặng",
    "trongTam": "Ôn thận trợ dương, khu phong tán hàn, thông kinh hoạt lạc.\nPhép châm: Bổ các huyệt thận kinh và bàng quang kinh.\nKết hợp ngải cứu tại các huyệt vùng thắt lưng để tán hàn, giảm đau.",
    "hinhMinhHoa": "https://suckhoedoisong.qltns.mediacdn.vn/324455921873985536/2024/4/29/screenshot20240429100641-17143316440831780551196.png",
    "huyetLienQuan": ["BL23", "GV4", "BL40", "KD3", "BL60", "GB30", "GV3", "BL25"]
  },
  {
    "ten": "Mất Ngủ, Hồi Hộp",
    "slug": "mat-ngu-hoi-hop",
    "trieuChung": "Khó ngủ hoặc ngủ không sâu giấc, hay giật mình, hồi hộp, lo lắng.\nNguyên nhân theo Đông y:\n• Tâm thần bất an — tâm huyết hư\n• Âm hư hỏa vượng — nhiệt quấy tâm thần\n• Can khí uất kết — lo lắng quá mức",
    "trongTam": "Dưỡng tâm an thần, tư âm thanh nhiệt.\nHuyệt trọng tâm: Thần Môn (HT7) — huyệt nguyên của Tâm kinh.\nCần kết hợp điều chỉnh sinh hoạt, thư giãn trước ngủ.",
    "hinhMinhHoa": "",
    "huyetLienQuan": ["HT7", "PC6", "SP6", "KD6", "BL15", "GV20", "BL44", "ST36"]
  },
  {
    "ten": "Ho, Hen Suyễn",
    "slug": "ho-hen-suyen",
    "trieuChung": "Ho có đờm hoặc ho khan, khó thở, ngực tức.\nPhân biệt:\n• Phế khí hư — ho yếu, tự ra mồ hôi\n• Phong hàn phạm Phế — ho do lạnh, sợ gió\n• Đờm thấp trở Phế — ho nhiều đờm trắng loãng\n• Âm hư Phế nhiệt — ho khan, đờm ít dính",
    "trongTam": "Tuyên Phế, giáng khí, hóa đờm bình suyễn.\nPhế du (BL13) + Trung Phủ (LU1): cặp huyệt bối du — mộ du điều Phế.\nĐịnh Suyễn (EX-B1): huyệt kinh ngoài chuyên trị hen.",
    "hinhMinhHoa": "https://cdn.hellobacsi.com/wp-content/uploads/2021/09/hen-suyen-khi-mang-thai-1.jpg",
    "huyetLienQuan": ["LU1", "LU7", "BL13", "ST40", "CV22", "CV17", "LI4", "KD27"]
  }
];
